'use strict';
const KEY = 'quickTodoTasks';
const list = document.getElementById('task-list');
const form = document.getElementById('add-form');
const input = document.getElementById('task-input');
const counter = document.getElementById('counter');
const summary = document.getElementById('summary');
const emptyState = document.getElementById('empty-state');
const clearButton = document.getElementById('clear-completed');
let tasks = [];
let draggedId = null;
let pointerDrag = null;
const makeId = () => crypto.randomUUID();
const status = document.getElementById('sync-status');
const backupPanel = document.getElementById('backup-panel');
const backupInput = document.getElementById('backup-data');
const feedback = document.getElementById('backup-feedback');
const SYNC_KEY = 'quickTodoSyncedV1';
const CHUNK_PREFIX = 'quickTodoChunk_';
let initialized = false;
let dirty = false;
let saveTimer = null;
let saving = Promise.resolve();
let lastRevision = '';
let editingTaskId = null;
let savingInFlight = false;
const deviceId = crypto.randomUUID();
const encoder = new TextEncoder();
function validTasks(value) {
  return Array.isArray(value) ? value.filter(t => t && typeof t.id === 'string' &&
    typeof t.text === 'string' && typeof t.done === 'boolean')
    .map(t => ({id:t.id, text:t.text.slice(0,240), done:t.done})) : [];
}
function setStatus(message, error = false) {
  status.textContent = message;
  status.classList.toggle('error', error);
}
function makeChunks(data) {
  const chunks = [];
  let current = [];
  for (const task of data) {
    const next = [...current, task];
    if (encoder.encode(JSON.stringify(next)).length + 35 > 6800 && current.length) {
      chunks.push(current);
      current = [task];
    } else current = next;
  }
  if (current.length) chunks.push(current);
  return chunks;
}
async function readSynced() {
  const metaData = await chrome.storage.sync.get(SYNC_KEY);
  const meta = metaData[SYNC_KEY];
  if (!meta || !Number.isInteger(meta.count) || meta.count < 0 || meta.count > 20 ||
      typeof meta.rev !== 'string') return null;
  const keys = Array.from({length:meta.count}, (_,i)=> CHUNK_PREFIX + i);
  const data = keys.length ? await chrome.storage.sync.get(keys) : {};
  if (keys.some(k => !Array.isArray(data[k]))) throw new Error('Sync is incomplete; retry shortly.');
  return {tasks:validTasks(keys.flatMap(k=>data[k])), rev:meta.rev};
}
async function writeSynced(snapshot) {
  const chunks = makeChunks(snapshot);
  if (chunks.length > 20) throw new Error('The list is too large for Chrome Sync. Export a backup.');
  const payload = Object.fromEntries(chunks.map((part,i)=>[CHUNK_PREFIX+i,part]));
  if (chunks.length) await chrome.storage.sync.set(payload);
  const rev = `${Date.now()}-${deviceId}-${crypto.randomUUID()}`;
  lastRevision = rev;
  await chrome.storage.sync.set({[SYNC_KEY]:{count:chunks.length, rev}});
  // Old chunks are left in place deliberately, so another Chrome session
  // reading the previous revision during a write will never see missing chunks.
}
function save() {
  if (!initialized) return;
  dirty = true;
  setStatus('Saving…');
  // Always keep a local backup even if sync quota or network availability fails.
  chrome.storage.local.set({[KEY]:tasks}).catch(()=>{});
  clearTimeout(saveTimer);
  saveTimer = setTimeout(flushSave, 450);
}
function flushSave() {
  if (!dirty) return;
  dirty = false;
  const snapshot = structuredClone(tasks);
  saving = saving.catch(()=>{}).then(async()=>{
    savingInFlight = true;
    try {
      await writeSynced(snapshot);
      setStatus(dirty ? 'Saving…' : 'Saved to Chrome Sync ✓');
    } catch(err) {
      setStatus('Not synced: '+err.message, true);
      // Retain local backup, and retry on a subsequent edit.
    } finally { savingInFlight = false; }
  });
}
async function initialize() {
  try {
    const local = await chrome.storage.local.get({[KEY]:[]});
    let remote;
    try { remote = await readSynced(); }
    catch (err) { setStatus('Sync temporarily unavailable; using local backup', true); }
    if (remote) {
      tasks = remote.tasks;
      lastRevision = remote.rev;
      await chrome.storage.local.set({[KEY]:tasks});
      setStatus('Saved to Chrome Sync ✓');
    } else {
      tasks = validTasks(local[KEY]);
      setStatus('Preparing Chrome Sync…');
    }
    initialized = true;
    render(); input.focus();
    if (!remote) save();
  } catch(err) {
    initialized = true;
    setStatus('Storage error: '+err.message,true);
    render();
  }
}
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'sync' || !changes[SYNC_KEY] || !initialized) return;
  const rev = changes[SYNC_KEY].newValue?.rev;
  if (!rev || rev === lastRevision || dirty || savingInFlight || editingTaskId) return;
  // Do not overwrite edits currently waiting to be written.
  saving.then(async()=>{
    if (dirty || savingInFlight || editingTaskId) return;
    try {
      const remote = await readSynced();
      if (!remote || remote.rev === lastRevision || dirty || savingInFlight || editingTaskId) return;
      lastRevision = remote.rev;
      tasks = remote.tasks;
      await chrome.storage.local.set({[KEY]:tasks});
      render();
      setStatus('Updated from Chrome Sync ✓');
    } catch(err) { setStatus('Sync temporarily unavailable',true); }
  });
});
document.getElementById('backup-button').addEventListener('click',()=>{
  backupPanel.hidden = !backupPanel.hidden;
  feedback.textContent = '';
});
document.getElementById('export-button').addEventListener('click',async()=>{
  const data = JSON.stringify(tasks,null,2);
  backupInput.value = data;
  try { await navigator.clipboard.writeText(data); feedback.textContent='Backup copied to clipboard.'; }
  catch { feedback.textContent='Select and copy the backup text above.'; }
});
document.getElementById('import-button').addEventListener('click',()=>{
  try {
    const parsed=JSON.parse(backupInput.value);
    if (!Array.isArray(parsed)) throw new Error('Expected a JSON task list.');
    const imported=validTasks(parsed);
    if (imported.length !== parsed.length) throw new Error('Some tasks are invalid.');
    if (!confirm(`Replace your current ${tasks.length} task(s) with ${imported.length} imported task(s)?`)) return;
    tasks=imported; save(); render(); feedback.textContent='List imported.';
  } catch(err) {feedback.textContent='Could not import: '+err.message;}
});

function render() {
  list.replaceChildren();
  for (const task of tasks) {
    const li = document.createElement('li');
    li.className = `task${task.done ? ' done' : ''}`;
    li.dataset.id = task.id;
    li.draggable = true;

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.className = 'task-checkbox';
    checkbox.checked = task.done;
    checkbox.setAttribute('aria-label', `Mark ${task.text} ${task.done ? 'not done' : 'done'}`);
    checkbox.addEventListener('change', () => { task.done = checkbox.checked; save(); render(); });

    const text = document.createElement('span');
    text.className = 'task-text';
    text.textContent = task.text;
    text.title = 'Double-click to edit';
    function startEditing() {
      if (editingTaskId) return;
      editingTaskId = task.id;
      li.draggable = false;
      const editor = document.createElement('input');
      editor.type = 'text';
      editor.className = 'task-editor';
      editor.maxLength = 240;
      editor.value = task.text;
      editor.setAttribute('aria-label', `Edit ${task.text}`);
      text.replaceWith(editor);
      let finished = false;
      const finish = (cancel = false) => {
        if (finished) return;
        finished = true;
        const changedText = editor.value.trim().slice(0, 240);
        editingTaskId = null;
        if (!cancel && changedText && changedText !== task.text) {
          task.text = changedText;
          save();
        }
        render();
      };
      editor.addEventListener('keydown', e => {
        if (e.key === 'Enter') { e.preventDefault(); finish(); }
        if (e.key === 'Escape') { e.preventDefault(); finish(true); }
      });
      editor.addEventListener('blur', () => finish());
      editor.focus();
      editor.select();
    }
    text.addEventListener('dblclick', startEditing);
    const edit = document.createElement('button');
    edit.className = 'task-edit';
    edit.type = 'button';
    edit.textContent = '✎';
    edit.title = 'Edit task';
    edit.setAttribute('aria-label', `Edit ${task.text}`);
    edit.addEventListener('click', startEditing);

    const del = document.createElement('button');
    del.className = 'task-delete';
    del.type = 'button';
    del.textContent = '×';
    del.title = 'Delete task';
    del.setAttribute('aria-label', `Delete ${task.text}`);
    del.addEventListener('click', () => { tasks = tasks.filter(t => t.id !== task.id); save(); render(); });

    const handle = document.createElement('button');
    handle.type = 'button';
    handle.className = 'task-handle';
    handle.textContent = '⠿';
    handle.title = 'Drag to reorder (or use arrow keys)';
    handle.setAttribute('aria-label', `Reorder ${task.text}; press up or down arrow`);
    handle.addEventListener('keydown', e => {
      if (e.key !== 'ArrowUp' && e.key !== 'ArrowDown') return;
      e.preventDefault();
      const index = tasks.findIndex(t => t.id === task.id);
      const next = index + (e.key === 'ArrowUp' ? -1 : 1);
      if (next < 0 || next >= tasks.length) return;
      [tasks[index], tasks[next]] = [tasks[next], tasks[index]];
      save(); render();
      list.children[next]?.querySelector('.task-handle')?.focus();
    });

    li.addEventListener('dragstart', e => {
      if (text.contentEditable === 'true') { e.preventDefault(); return; }
      draggedId = task.id;
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', task.id);
      li.classList.add('dragging');
    });
    li.addEventListener('dragover', e => {
      e.preventDefault();
      if (draggedId !== task.id) li.classList.add('drag-over');
      e.dataTransfer.dropEffect = 'move';
    });
    li.addEventListener('dragleave', () => li.classList.remove('drag-over'));
    li.addEventListener('drop', e => {
      e.preventDefault(); li.classList.remove('drag-over');
      if (draggedId && draggedId !== task.id) move(draggedId, task.id);
    });
    li.addEventListener('dragend', () => {
      draggedId = null;
      [...list.children].forEach(el => el.classList.remove('dragging', 'drag-over'));
    });
    // Pointer dragging on the grip also supports touchscreens and touch-enabled laptops.
    handle.addEventListener('pointerdown', e => {
      if (e.button !== 0) return;
      pointerDrag = { id: task.id, startY: e.clientY, active: false };
      handle.setPointerCapture(e.pointerId);
    });
    handle.addEventListener('pointermove', e => {
      if (!pointerDrag || pointerDrag.id !== task.id) return;
      if (Math.abs(e.clientY - pointerDrag.startY) > 5) pointerDrag.active = true;
      if (!pointerDrag.active) return;
      document.querySelectorAll('.drag-over').forEach(el => el.classList.remove('drag-over'));
      const target = document.elementFromPoint(e.clientX, e.clientY)?.closest('.task');
      if (target && target !== li) target.classList.add('drag-over');
    });
    handle.addEventListener('pointerup', e => {
      if (!pointerDrag || pointerDrag.id !== task.id) return;
      const wasActive = pointerDrag.active;
      pointerDrag = null;
      const target = document.elementFromPoint(e.clientX, e.clientY)?.closest('.task');
      if (wasActive && target && target.dataset.id !== task.id) move(task.id, target.dataset.id);
      document.querySelectorAll('.drag-over').forEach(el => el.classList.remove('drag-over'));
    });
    handle.addEventListener('pointercancel', () => { pointerDrag = null; document.querySelectorAll('.drag-over').forEach(el => el.classList.remove('drag-over')); });

    li.append(checkbox, text, edit, del, handle);
    list.append(li);
  }
  const done = tasks.filter(t => t.done).length;
  const left = tasks.length - done;
  counter.textContent = `${left} left`;
  summary.textContent = tasks.length ? `${done} of ${tasks.length} completed` : 'A little progress adds up.';
  clearButton.hidden = done === 0;
  emptyState.hidden = tasks.length !== 0;
}

function move(sourceId, targetId) {
  const from = tasks.findIndex(t => t.id === sourceId);
  const to = tasks.findIndex(t => t.id === targetId);
  if (from < 0 || to < 0 || from === to) return;
  const [item] = tasks.splice(from, 1);
  tasks.splice(to, 0, item);
  save(); render();
}

form.addEventListener('submit', e => {
  e.preventDefault();
  const text = input.value.trim();
  if (!text) return;
  tasks.unshift({ id: makeId(), text, done: false });
  input.value = '';
  save(); render(); input.focus();
});
clearButton.addEventListener('click', () => { tasks = tasks.filter(t => !t.done); save(); render(); });
initialize();
